const Blockchain = require('./blockchain');
const bitcoin = new Blockchain();

 const bc1 = {
    "chain": [
        {
        "index": 1,
        "timestamp": 1645970029916,
        "transactions": [],
        "nonce": 100,
        "hash": "0",
        "previousBlockHash": "0"
        },
        {
        "index": 2,
        "timestamp": 1645970059855,
        "transactions": [],
        "nonce": 18140,
        "hash": "0000b9135b054d1131392c9eb9d03b0111d4b516824a03c35639e12858912100",
        "previousBlockHash": "0"
        },
        {
        "index": 3,
        "timestamp": 1645970170266,
        "transactions": [
        {
        "amount": 12.5,
        "sender": "00",
        "recipient": "b0f1f2b097d411ec9e64f331ec375025",
        "transactionId": "c2ce8ca097d411ec9e64f331ec375025"
        },
        {
        "amount": 5,
        "sender": "HJKTJTJTJZTK",
        "recipient": "ASDGSGDSGSG",
        "transactionId": "ef40921097d411ec9e64f331ec375025"
        },
        {
        "amount": 55,
        "sender": "HJKTJTJTJZTK",
        "recipient": "ASDGSGDSGSG",
        "transactionId": "f943e50097d411ec9e64f331ec375025"
        },
        {
        "amount": 50,
        "sender": "HJKTJTJTJZTK",
        "recipient": "ASDGSGDSGSG",
        "transactionId": "faf2585097d411ec9e64f331ec375025"
        }
        ],
        "nonce": 24253,
        "hash": "0000977e08e5aa8eca64f28b790a0e3f116b346512d5e6191953056c735f3180",
        "previousBlockHash": "0000b9135b054d1131392c9eb9d03b0111d4b516824a03c35639e12858912100"
        },
        {
        "index": 4,
        "timestamp": 1645970242261,
        "transactions": [
        {
        "amount": 12.5,
        "sender": "00",
        "recipient": "b0f1f2b097d411ec9e64f331ec375025",
        "transactionId": "049a1dc097d511ec9e64f331ec375025"
        },
        {
        "amount": 50,
        "sender": "HJKTJTJTJZTK",
        "recipient": "ASDGSGDSGSG",
        "transactionId": "2d3fd8f097d511ec9e64f331ec375025"
        },
        {
        "amount": 50,
        "sender": "HJKTJTJTJZTK",
        "recipient": "ASDGSGDSGSG",
        "transactionId": "2d95730097d511ec9e64f331ec375025"
        }
        ],
        "nonce": 49627,
        "hash": "000005041b30940d1ab9da8e13d8b9ddb20ed6deedd571a12c8cf4151108f9f3",
        "previousBlockHash": "0000977e08e5aa8eca64f28b790a0e3f116b346512d5e6191953056c735f3180"
        },
        {
        "index": 5,
        "timestamp": 1645970255280,
        "transactions": [
        {
        "amount": 12.5,
        "sender": "00",
        "recipient": "b0f1f2b097d411ec9e64f331ec375025",
        "transactionId": "2f83ae7097d511ec9e64f331ec375025"
        }
        ],
        "nonce": 89716,
        "hash": "0000c7e3127f90ed6f8233e2c04b1161d5cab54d6b195c53b62084d3d8f10d48",
        "previousBlockHash": "000005041b30940d1ab9da8e13d8b9ddb20ed6deedd571a12c8cf4151108f9f3"
        },
        {
        "index": 6,
        "timestamp": 1645970257028,
        "transactions": [
        {
        "amount": 12.5,
        "sender": "00",
        "recipient": "b0f1f2b097d411ec9e64f331ec375025",
        "transactionId": "3746392097d511ec9e64f331ec375025"
        }
        ],
        "nonce": 44674,
        "hash": "00009d15878bd5be63a9a6cfd3f4aded28b8f1a595d400bd0456777788ac147a",
        "previousBlockHash": "0000c7e3127f90ed6f8233e2c04b1161d5cab54d6b195c53b62084d3d8f10d48"
        }
        ],
        "pendingTransactions": [
        {
        "amount": 12.5,
        "sender": "00",
        "recipient": "b0f1f2b097d411ec9e64f331ec375025",
        "transactionId": "3850cb5097d511ec9e64f331ec375025"
        }
        ],
        "currentNodeUrl": "http://localhost:3001",
        "networkNodes": []
 };

 console.log('VALID:', bitcoin.chainIsValid(bc1.chain));
